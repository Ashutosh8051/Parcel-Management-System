document.getElementById('registrationForm').addEventListener('submit', function(e) {
  const mobile = document.getElementById('mobile').value;
  const zip = document.getElementById('zip').value;
  const postal = document.getElementById('postal').value;
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirmPassword').value;

  const mobileRegex = /^\d{10}$/;
  const zipRegex = /^\d{6}$/;
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{1,30}$/;

  if (!mobileRegex.test(mobile)) {
    e.preventDefault();
    alert('Mobile number must be exactly 10 digits.');
    return;
  }

  if (!zipRegex.test(zip)) {
    e.preventDefault();
    alert('Zip Code must be exactly 6 digits.');
    return;
  }

  if (!zipRegex.test(postal)) {
    e.preventDefault();
    alert('Postal Code must be exactly 6 digits.');
    return;
  }

  if (!passwordRegex.test(password)) {
    e.preventDefault();
    alert('Password must contain at least one lowercase letter, one uppercase letter, one numeric value, and one special character.');
    return;
  }

  if (password !== confirmPassword) {
    e.preventDefault();
    alert('Passwords do not match.');
    return;
  }

});
