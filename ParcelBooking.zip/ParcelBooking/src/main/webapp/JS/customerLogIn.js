
window.addEventListener("DOMContentLoaded", function () {
  document.getElementById("loginForm").addEventListener("submit", function (e) {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value;

    if (username.length < 5 || username.length > 20) {
      e.preventDefault();
      alert("Username must be between 5 and 20 characters.");
      return;
    }

    if (password.length === 0) {
      e.preventDefault();
      alert("Password is required.");
      return;
    }
  });
});